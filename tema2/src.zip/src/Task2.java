import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Objects;
import java.util.concurrent.ExecutorService;

public class Task2 implements Runnable{
    private final String orderId;
    private final ExecutorService pool1;
    private final ExecutorService pool2;
    private final long startPos;
    private RandomAccessFile file;

    public Task2(String orderId, ExecutorService pool1, ExecutorService pool2, long startPos) throws FileNotFoundException {
        this.orderId = orderId;
        this.startPos = startPos;
        this.pool1 = pool1;
        this.pool2 = pool2;
        this.file = new RandomAccessFile(Tema2.products, "r");
    }

    private String[] parseLine(String line) {
        return line.split(",");
    }

    private void findOrder() throws IOException {
        file.seek(startPos);

        while(file.getFilePointer() < Tema2.productsFileLength) {
            String[] elems = parseLine(file.readLine());
            String lineOrderId = elems[0];
            String lineProductId = elems[1];

            if (Objects.equals(lineOrderId, orderId)) {
                writeOutput(lineProductId);
                closeTask();
                return;
            }
        }

        closeTask();
    }

    private void closeTask() throws IOException {
        Tema2.orderToObjects.put(orderId, Tema2.orderToObjects.get(orderId) - 1);

        // didn't finish the order yet => new task starting from where this one stopped
        if (Tema2.orderToObjects.get(orderId) > 0) {
            pool2.submit(new Task2(orderId, pool1, pool2, file.getFilePointer()));
        } else {
            pool1.submit(new Task1Writer(pool1, pool2, orderId));
        }

        file.close();
    }

    private void writeOutput(String productId) throws IOException {
        synchronized (Tema2.orderProductsOutFile) {
            Tema2.orderProductsOutFile.print(orderId + "," + productId + ",shipped\n");
        }
    }

    @Override
    public void run() {
        try {
//            System.out.println(startPos);
            findOrder();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
